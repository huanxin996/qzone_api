
<!-- markdownlint-disable MD033 MD036 MD041 -->

<p align="center">
  <a href="https://huanxinbot.com/"><img src="https://raw.githubusercontent.com/huanxin996/nonebot_plugin_hx-yinying/main/.venv/hx_img.png" width="200" height="200" alt="这里放一张"></a>
</p>

<div align="center">

# QQ 空间 Api 封装

_✨ 电脑网页版空间api操作 ✨_

</div>

## 安装

pip安装

```dotenv
pip install qzone-api
```

## 目前实现的方法

- 获取指定QQ的动态
- 获取好友空间动态
- 点赞指定动态
- 向指定动态下评论(文本)
- 发送文本动态
- 删除指定动态(需为自身)

## 使用方式  

utils里是示例  
parms 是构建参数  
api 里是api调用方法，也可以自己构建  
本人代码水平有限，写的很简单,毕竟主要是自用，有问题请提iss  
