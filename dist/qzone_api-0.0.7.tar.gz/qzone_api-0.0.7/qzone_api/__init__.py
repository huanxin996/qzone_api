from .api import *

__all__ = ["QzoneApi"]
__version__ = "0.0.1"
__author__ = "Huan Xin"
__email__ = "mc.xiaolang@foxmail.com"

QzoneApi = QzoneApi()
"""
QQ空间API封装
"""
